import React from 'react';
import './Card.css';


const Card = ({name, email, id}) => {
// const {name, email, id } = props;

        return (
            <div className="bg-washed-blue dib br3 pa3 ma3 grow bw2 shadow-5">
            <img src={`https://robohash.org/${id}?size=150x150`} alt={`profile ${id}`}></img>
                <h4>{name}</h4>
                <p>{email}</p>
            </div>
        );

    }

export default Card;