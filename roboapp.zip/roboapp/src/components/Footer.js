import React from 'react';
import './Footer.css'

const Footer = () => {
    return (
        <div className='pa2 footer'>
<p>&copy; 2019 DataUI App</p>
</div>
    );
}


export default Footer;