import React, { Component } from 'react';
import './Hello.css';


class Hello extends Component {
    render() {

        return (
            <div className="allo fi tc">
                <h2>Allo</h2>
                <p>App Welcome</p>
            </div>
        );

    }
}

export default Hello;