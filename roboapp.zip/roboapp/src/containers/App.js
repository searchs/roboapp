import React, { Component } from 'react';
// import logo from './logo.svg';
import './App.css';
import CardList from '../components/CardList';
import SearchBox from '../components/SearchBox';
import Footer from '../components/Footer';
import Scroll from '../components/Scroll';
import { localRobots } from '../data/robots';

import ErrorBoundary from '../components/ErrorBoundary';


class App extends Component {
  constructor() {
    super();
    this.state = {
      robots: [],
      searchfield: ''
    }
  }
  

  componentDidMount() {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => {
        return response.json();
      })
      .then(users => {
        this.setState({ robots: users })

      });
  }

  onSearchChange = (event) => {
    this.setState({ searchfield: event.target.value })
  }

  render() {
    const { robots, searchfield } = this.state;
    const filteredRobots = this.state.robots.filter(robot => {
      return robot.name.toLowerCase().includes(searchfield.toLowerCase())
    })
    if(robots.length === 0 ){
      this.setState({robots: localRobots})
      return <h2>Loading.....</h2>

    } else {
    
    return (
      <div className="tc">
        <header className="App-header">
          <SearchBox searchChange={this.onSearchChange} />
        </header>
        <Scroll>
          <ErrorBoundary>
        <CardList robots={filteredRobots} />
        </ErrorBoundary>
        </Scroll>
        <Footer />
      </div>
    );
  }
  }
}

export default App;
